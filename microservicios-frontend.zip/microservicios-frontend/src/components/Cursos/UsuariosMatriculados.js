import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const UsuariosMatriculados = () => {
  const { id } = useParams(); // ID del curso
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    const fetchUsuarios = async () => {
      const response = await axios.get(`http://127.0.0.1:53390/api/cursos/${id}/usuarios`);
      setUsuarios(response.data);
    };
    fetchUsuarios();
  }, [id]);

  const handleDesmatricular = async (usuarioId) => {
    if (window.confirm('¿Está seguro de que desea desmatricular a este usuario?')) {
      await axios.delete(`http://127.0.0.1:53390/api/cursos/${id}/usuarios/${usuarioId}`);
      setUsuarios(usuarios.filter(usuario => usuario.id !== usuarioId));
    }
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '700px',
        marginTop: '4rem',
        padding: '2.5rem',
        backgroundColor: '#f7f7f7',
        borderRadius: '10px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Usuarios Matriculados
      </h2>

      <ul style={{ listStyleType: 'none', paddingLeft: '0' }}>
        {usuarios.map((usuario) => (
          <li
            key={usuario.id}
            style={{
              padding: '1rem',
              marginBottom: '1rem',
              backgroundColor: '#fff',
              borderRadius: '8px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span
              style={{
                fontSize: '1.1rem',
                fontWeight: 'bold',
                color: '#555',
              }}
            >
              {usuario.nombre} {usuario.apellido} - {usuario.email}
            </span>
            <button
              className="btn btn-danger btn-sm"
              onClick={() => handleDesmatricular(usuario.id)}
              style={{
                backgroundColor: '#dc3545',
                borderRadius: '5px',
                color: 'white',
                padding: '0.5rem 1.2rem',
                border: 'none',
                cursor: 'pointer',
                fontSize: '0.9rem',
                transition: 'background-color 0.3s',
              }}
            >
              Desmatricular
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UsuariosMatriculados;
