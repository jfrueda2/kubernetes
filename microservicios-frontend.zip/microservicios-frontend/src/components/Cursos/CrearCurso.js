import React, { useState } from 'react';
import { createCurso } from '../../services/cursoService';
import { useNavigate } from 'react-router-dom';

const CrearCurso = () => {
  const [curso, setCurso] = useState({
    nombre: '',
    descripcion: '',
    creditos: 0,
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurso({ ...curso, [name]: value });
  };

  const validate = () => {
    const errors = {};

    if (!curso.nombre.trim()) {
      errors.nombre = 'El nombre es obligatorio';
    } else if (curso.nombre.length < 3) {
      errors.nombre = 'El nombre debe tener al menos 3 caracteres';
    }

    if (!curso.descripcion.trim()) {
      errors.descripcion = 'La descripción es obligatoria';
    } else if (curso.descripcion.length < 10) {
      errors.descripcion = 'La descripción debe tener al menos 10 caracteres';
    }

    if (curso.creditos <= 0) {
      errors.creditos = 'Los créditos deben ser un número mayor a 0';
    }

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      try {
        await createCurso(curso);
        alert('Curso creado exitosamente');
        navigate('/cursos');
      } catch (error) {
        console.error('Error al crear curso:', error);
        alert('Hubo un error al crear el curso. Por favor, inténtelo nuevamente.');
      }
    }
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '600px',
        margin: '2rem auto',
        padding: '2rem',
        background: 'linear-gradient(135deg, #ffffff, #f0f0f0)',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
        borderRadius: '15px',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Crear Curso
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Nombre
          </label>
          <input
            type="text"
            className="form-control"
            name="nombre"
            value={curso.nombre}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.nombre && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.nombre}
            </div>
          )}
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Descripción
          </label>
          <textarea
            className="form-control"
            name="descripcion"
            value={curso.descripcion}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
              height: '100px',
            }}
          />
          {errors.descripcion && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.descripcion}
            </div>
          )}
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Créditos
          </label>
          <input
            type="number"
            className="form-control"
            name="creditos"
            value={curso.creditos}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.creditos && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.creditos}
            </div>
          )}
        </div>
        <button
          type="submit"
          className="btn btn-success"
          style={{
            backgroundColor: '#28a745',
            border: 'none',
            padding: '0.75rem 1.5rem',
            fontSize: '1rem',
            color: 'white',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background-color 0.3s ease',
          }}
          onMouseOver={(e) => (e.target.style.backgroundColor = '#218838')}
          onMouseOut={(e) => (e.target.style.backgroundColor = '#28a745')}
        >
          Crear
        </button>
      </form>
    </div>
  );
};

export default CrearCurso;
