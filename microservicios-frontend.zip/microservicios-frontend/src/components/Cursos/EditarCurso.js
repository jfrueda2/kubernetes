import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getCursoById, updateCurso } from '../../services/cursoService';

const EditarCurso = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [curso, setCurso] = useState({ nombre: '', descripcion: '', creditos: 0 });

  useEffect(() => {
    const fetchCurso = async () => {
      const { data } = await getCursoById(id);
      setCurso(data);
    };
    fetchCurso();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurso({ ...curso, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateCurso(id, curso);
    navigate('/cursos');
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '600px',
        marginTop: '3rem',
        padding: '2rem',
        background: 'linear-gradient(135deg, #f9f9f9, #f0f0f0)',
        borderRadius: '15px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Editar Curso
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Nombre
          </label>
          <input
            type="text"
            className="form-control"
            name="nombre"
            value={curso.nombre}
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Descripción
          </label>
          <textarea
            className="form-control"
            name="descripcion"
            value={curso.descripcion}
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Créditos
          </label>
          <input
            type="number"
            className="form-control"
            name="creditos"
            value={curso.creditos}
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>
        <div className="d-flex justify-content-center">
          <button
            type="submit"
            className="btn"
            style={{
              backgroundColor: '#28a745',
              color: 'white',
              padding: '0.75rem 3rem',
              fontSize: '1.1rem',
              borderRadius: '10px',
              boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
              transition: 'background-color 0.3s ease',
            }}
          >
            Actualizar
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditarCurso;
