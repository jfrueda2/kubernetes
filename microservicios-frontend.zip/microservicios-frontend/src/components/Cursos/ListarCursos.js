import React, { useEffect, useState } from 'react';
import { getCursos, deleteCurso } from '../../services/cursoService';
import { Link } from 'react-router-dom';

const ListarCursos = () => {
  const [cursos, setCursos] = useState([]);
  const [mensajeError, setMensajeError] = useState('');

  useEffect(() => {
    fetchCursos();
  }, []);

  const fetchCursos = async () => {
    const { data } = await getCursos();
    setCursos(data);
  };

  const handleDelete = async (id) => {
    try {
      // Primero verificamos si el curso tiene usuarios matriculados
      const response = await fetch(`http://127.0.0.1:53390/api/cursos/${id}/usuarios`);
      const usuariosMatriculados = await response.json();

      // Si hay usuarios matriculados, mostramos el mensaje de error
      if (usuariosMatriculados.length > 0) {
        setMensajeError('No se puede eliminar el curso porque hay personas matriculadas.');
        return;
      }

      // Si no hay usuarios matriculados, procedemos con la eliminación
      if (window.confirm('¿Está seguro de que desea eliminar este curso?')) {
        await deleteCurso(id);
        fetchCursos();
      }
    } catch (error) {
      console.error('Error al eliminar curso:', error);
      setMensajeError('Hubo un problema al intentar eliminar el curso.');
    }
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '1000px',
        marginTop: '3rem',
        padding: '2rem',
        background: 'linear-gradient(135deg, #f9f9f9, #f0f0f0)',
        borderRadius: '15px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Cursos
      </h2>
      <div className="text-end">
        <Link
          to="/cursos/crear"
          className="btn"
          style={{
            backgroundColor: '#28a745',
            color: 'white',
            borderRadius: '8px',
            padding: '0.75rem 2rem',
            fontSize: '1rem',
            transition: 'background-color 0.3s ease',
          }}
        >
          Crear Curso
        </Link>
      </div>

      {/* Mostrar mensaje de error si existe */}
      {mensajeError && (
        <div style={{ color: 'red', textAlign: 'center', marginBottom: '1rem' }}>
          {mensajeError}
        </div>
      )}

      <table
        className="table table-bordered"
        style={{
          marginTop: '2rem',
          borderCollapse: 'collapse',
          backgroundColor: '#fff',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        }}
      >
        <thead>
          <tr style={{ backgroundColor: '#f1f1f1' }}>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>ID</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Nombre</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Descripción</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Créditos</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {cursos.map(curso => (
            <tr key={curso.id}>
              <td style={{ padding: '1rem', color: '#555' }}>{curso.id}</td>
              <td style={{ padding: '1rem', color: '#555' }}>{curso.nombre}</td>
              <td style={{ padding: '1rem', color: '#555' }}>{curso.descripcion}</td>
              <td style={{ padding: '1rem', color: '#555' }}>{curso.creditos}</td>
              <td style={{ padding: '1rem' }}>
                <Link
                  to={`/cursos/editar/${curso.id}`}
                  className="btn btn-sm"
                  style={{
                    backgroundColor: '#ffc107',
                    color: 'white',
                    borderRadius: '8px',
                    padding: '0.5rem 1rem',
                    marginRight: '0.5rem',
                    fontSize: '0.9rem',
                    transition: 'background-color 0.3s ease',
                  }}
                >
                  Editar
                </Link>
                <Link
                  to={`/cursos/${curso.id}/usuarios`}
                  className="btn btn-sm"
                  style={{
                    backgroundColor: '#17a2b8',
                    color: 'white',
                    borderRadius: '8px',
                    padding: '0.5rem 1rem',
                    marginRight: '0.5rem',
                    fontSize: '0.9rem',
                    transition: 'background-color 0.3s ease',
                  }}
                >
                  Ver Usuarios
                </Link>
                <button
                  className="btn btn-sm"
                  style={{
                    backgroundColor: '#dc3545',
                    color: 'white',
                    borderRadius: '8px',
                    padding: '0.5rem 1rem',
                    fontSize: '0.9rem',
                    transition: 'background-color 0.3s ease',
                  }}
                  onClick={() => handleDelete(curso.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ListarCursos;
