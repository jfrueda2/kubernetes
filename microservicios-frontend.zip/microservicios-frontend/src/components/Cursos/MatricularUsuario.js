import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MatricularUsuario = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [form, setForm] = useState({ usuarioId: '', cursoId: '' });
  const [mensajeError, setMensajeError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const usuariosResponse = await axios.get('http://127.0.0.1:53383/api/usuarios');
      const cursosResponse = await axios.get('http://127.0.0.1:53390/api/cursos');
      setUsuarios(usuariosResponse.data);
      setCursos(cursosResponse.data);
    };
    fetchData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
    setMensajeError(''); // Resetea el mensaje de error cuando el usuario o curso cambian
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Verifica si el usuario ya está matriculado en el curso
    try {
      const response = await axios.get(
        `http://127.0.0.1:53390/api/cursos/${form.cursoId}/usuarios`
      );

      // Verifica si el usuario ya existe en el curso
      const usuarioMatriculado = response.data.find(
        (usuario) => usuario.id === form.usuarioId
      );

      if (usuarioMatriculado) {
        setMensajeError('El usuario ya está matriculado en este curso.');
        return; // No hace nada si ya está matriculado
      }

      // Si no está matriculado, realiza la matriculación
      await axios.post(`http://127.0.0.1:53390/api/cursos/${form.cursoId}`, { id: form.usuarioId });
      alert('Usuario matriculado correctamente');
    } catch (error) {
      console.error('Error al verificar matrícula:', error);
      setMensajeError('Usuario ya Matriculado.');
    }
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '600px',
        marginTop: '4rem',
        padding: '2.5rem',
        backgroundColor: '#f7f7f7',
        borderRadius: '10px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Matricular Usuario en Curso
      </h2>

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Usuario
          </label>
          <select
            className="form-control"
            name="usuarioId"
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              marginBottom: '1.2rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          >
            <option value="">Seleccione un usuario</option>
            {usuarios.map((usuario) => (
              <option key={usuario.id} value={usuario.id}>
                {usuario.nombre} {usuario.apellido}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-4">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Curso
          </label>
          <select
            className="form-control"
            name="cursoId"
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              marginBottom: '1.2rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          >
            <option value="">Seleccione un curso</option>
            {cursos.map((curso) => (
              <option key={curso.id} value={curso.id}>
                {curso.nombre}
              </option>
            ))}
          </select>
        </div>

        {/* Mostrar el mensaje de error si existe */}
        {mensajeError && (
          <div style={{ color: 'red', textAlign: 'center', marginBottom: '1rem' }}>
            {mensajeError}
          </div>
        )}

        <div className="d-flex justify-content-center">
          <button
            type="submit"
            className="btn"
            style={{
              backgroundColor: '#007bff',
              color: 'white',
              padding: '0.75rem 2.5rem',
              fontSize: '1.1rem',
              borderRadius: '10px',
              boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
              transition: 'background-color 0.3s ease',
            }}
          >
            Matricular
          </button>
        </div>
      </form>
    </div>
  );
};

export default MatricularUsuario;
