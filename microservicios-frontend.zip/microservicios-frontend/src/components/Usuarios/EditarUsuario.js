import React, { useEffect, useState } from 'react';
import { getUsuarioById, updateUsuario } from '../../services/usuarioService';
import { useNavigate, useParams } from 'react-router-dom';

const EditarUsuario = () => {
  const { id } = useParams();
  const [usuario, setUsuario] = useState({ nombre: '', email: '' });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsuario = async () => {
      const { data } = await getUsuarioById(id);
      setUsuario(data);
    };
    fetchUsuario();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUsuario({ ...usuario, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateUsuario(id, usuario);
    navigate('/usuarios');
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '600px',
        marginTop: '3rem',
        padding: '2rem',
        background: 'linear-gradient(135deg, #f9f9f9, #f0f0f0)',
        borderRadius: '15px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Editar Usuario
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Nombre
          </label>
          <input
            type="text"
            className="form-control"
            name="nombre"
            value={usuario.nombre}
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Email
          </label>
          <input
            type="email"
            className="form-control"
            name="email"
            value={usuario.email}
            onChange={handleChange}
            required
            style={{
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>
        <div className="d-flex justify-content-center">
          <button
            type="submit"
            className="btn"
            style={{
              backgroundColor: '#28a745',
              color: 'white',
              padding: '0.75rem 3rem',
              fontSize: '1.1rem',
              borderRadius: '10px',
              boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
              transition: 'background-color 0.3s ease',
            }}
          >
            Actualizar
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditarUsuario;
