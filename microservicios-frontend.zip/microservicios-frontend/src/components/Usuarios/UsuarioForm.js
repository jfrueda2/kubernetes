import React, { useState } from 'react';
import axios from 'axios';

const UsuarioForm = ({ onSave }) => {
  const [form, setForm] = useState({ nombre: '', email: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await axios.post('http://127.0.0.1:53383/api/usuarios', form);
    onSave(response.data);
    setForm({ nombre: '', email: '' });
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '500px',
        marginTop: '3rem',
        padding: '2rem',
        backgroundColor: '#f9f9f9',
        borderRadius: '15px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Crear Usuario
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Nombre
          </label>
          <input
            type="text"
            name="nombre"
            value={form.nombre}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              marginBottom: '1.2rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>

        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '0.5rem',
            }}
          >
            Email
          </label>
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '0.75rem',
              borderRadius: '8px',
              border: '1px solid #ccc',
              fontSize: '1rem',
              marginBottom: '1.2rem',
              boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
            }}
          />
        </div>

        <div className="d-flex justify-content-center">
          <button
            type="submit"
            className="btn"
            style={{
              backgroundColor: '#28a745',
              color: 'white',
              padding: '0.75rem 3rem',
              fontSize: '1.1rem',
              borderRadius: '10px',
              boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
              transition: 'background-color 0.3s ease',
            }}
          >
            Guardar
          </button>
        </div>
      </form>
    </div>
  );
};

export default UsuarioForm;
