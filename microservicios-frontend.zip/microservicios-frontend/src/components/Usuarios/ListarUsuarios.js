import React, { useEffect, useState } from 'react';
import { getUsuarios, deleteUsuario } from '../../services/usuarioService';
import { Link } from 'react-router-dom';

const ListarUsuarios = () => {
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    fetchUsuarios();
  }, []);

  const fetchUsuarios = async () => {
    const { data } = await getUsuarios();
    setUsuarios(data);
  };

  const handleDelete = async (id) => {
    if (window.confirm('¿Está seguro de que desea eliminar este usuario?')) {
      await deleteUsuario(id);
      fetchUsuarios();
    }
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '1000px',
        marginTop: '3rem',
        padding: '2rem',
        background: 'linear-gradient(135deg, #f9f9f9, #f0f0f0)',
        borderRadius: '15px',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Usuarios
      </h2>
      <div className="text-end">
        <Link
          to="/usuarios/crear"
          className="btn"
          style={{
            backgroundColor: '#28a745',
            color: 'white',
            borderRadius: '8px',
            padding: '0.75rem 2rem',
            fontSize: '1rem',
            transition: 'background-color 0.3s ease',
          }}
        >
          Crear Usuario
        </Link>
      </div>

      <table
        className="table table-bordered"
        style={{
          marginTop: '2rem',
          borderCollapse: 'collapse',
          backgroundColor: '#fff',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        }}
      >
        <thead>
          <tr style={{ backgroundColor: '#f1f1f1' }}>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>ID</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Nombre</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Email</th>
            <th style={{ padding: '0.75rem', fontWeight: 'bold', color: '#333' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {usuarios.map(usuario => (
            <tr key={usuario.id}>
              <td style={{ padding: '1rem', color: '#555' }}>{usuario.id}</td>
              <td style={{ padding: '1rem', color: '#555' }}>{usuario.nombre}</td>
              <td style={{ padding: '1rem', color: '#555' }}>{usuario.email}</td>
              <td style={{ padding: '1rem' }}>
                <Link
                  to={`/usuarios/editar/${usuario.id}`}
                  className="btn btn-sm"
                  style={{
                    backgroundColor: '#007bff',
                    color: 'white',
                    borderRadius: '8px',
                    padding: '0.5rem 1rem',
                    marginRight: '0.5rem',
                    fontSize: '0.9rem',
                    transition: 'background-color 0.3s ease',
                  }}
                >
                  Editar
                </Link>
                <button
                  className="btn btn-sm"
                  style={{
                    backgroundColor: '#dc3545',
                    color: 'white',
                    borderRadius: '8px',
                    padding: '0.5rem 1rem',
                    fontSize: '0.9rem',
                    transition: 'background-color 0.3s ease',
                  }}
                  onClick={() => handleDelete(usuario.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ListarUsuarios;
