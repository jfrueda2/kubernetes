import React, { useState } from 'react';
import { createUsuario } from '../../services/usuarioService';
import { useNavigate } from 'react-router-dom';

const CrearUsuario = () => {
  const [usuario, setUsuario] = useState({
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    fechaNacimiento: '',
    creadoEn: '', // Agregar el campo creadoEn
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUsuario({ ...usuario, [name]: value });
  };

  const validate = () => {
    const errors = {};

    if (!usuario.nombre.trim()) errors.nombre = 'El nombre es obligatorio';

    if (!usuario.apellido.trim()) errors.apellido = 'El apellido es obligatorio';

    if (!/^[^\\s@]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+$/.test(usuario.email)) {
      errors.email = 'El formato del email no es válido';
    }
  
    if (!/^[0-9]{10}$/.test(usuario.telefono)) {
      errors.telefono = 'El teléfono debe tener 10 dígitos';
    }

    const fechaActual = new Date();
    const fechaNacimiento = new Date(usuario.fechaNacimiento);
    if (!usuario.fechaNacimiento) {
      errors.fechaNacimiento = 'La fecha de nacimiento es obligatoria';
    } else if (fechaNacimiento > fechaActual) {
      errors.fechaNacimiento = 'La fecha de nacimiento no puede ser futura';
    }

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      try {
        const usuarioConFecha = {
          ...usuario,
          fechaNacimiento: new Date(usuario.fechaNacimiento),
          creadoEn: new Date(),
        };
        await createUsuario(usuarioConFecha);
        alert('Usuario creado exitosamente');
        navigate('/usuarios');
      } catch (error) {
        console.error('Error al crear usuario:', error);
        alert('Hubo un error al crear el usuario. Por favor, inténtelo nuevamente.');
      }
    }
  };

  const obtenerFechaActual = () => {
    const hoy = new Date();
    const año = hoy.getFullYear();
    const mes = String(hoy.getMonth() + 1).padStart(2, '0');
    const día = String(hoy.getDate()).padStart(2, '0');
    return `${año}-${mes}-${día}`;
  };

  return (
    <div
      className="container"
      style={{
        maxWidth: '600px',
        margin: '2rem auto',
        padding: '2rem',
        background: 'linear-gradient(135deg, #ffffff, #f0f0f0)',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
        borderRadius: '15px',
      }}
    >
      <h2
        style={{
          fontSize: '2rem',
          color: '#333',
          marginBottom: '1.5rem',
          textAlign: 'center',
          fontWeight: 'bold',
          textTransform: 'uppercase',
        }}
      >
        Crear Usuario
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Nombre
          </label>
          <input
            type="text"
            className="form-control"
            name="nombre"
            value={usuario.nombre}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.nombre && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.nombre}
            </div>
          )}
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Apellido
          </label>
          <input
            type="text"
            className="form-control"
            name="apellido"
            value={usuario.apellido}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.apellido && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.apellido}
            </div>
          )}
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Email
          </label>
          <input
            type="email"
            className="form-control"
            name="email"
            value={usuario.email}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.email && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.email}
            </div>
          )}
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Teléfono
          </label>
          <input
            type="text"
            className="form-control"
            name="telefono"
            value={usuario.telefono}
            onChange={handleChange}
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.telefono && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.telefono}
            </div>
          )}
        </div>
        <div className="mb-3">
          <label
            className="form-label"
            style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: '#555',
            }}
          >
            Fecha de Nacimiento
          </label>
          <input
            type="date"
            className="form-control"
            name="fechaNacimiento"
            value={usuario.fechaNacimiento}
            onChange={handleChange}
            max={obtenerFechaActual()} // Establecer la fecha máxima como hoy
            required
            style={{
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '0.75rem',
              fontSize: '1rem',
            }}
          />
          {errors.fechaNacimiento && (
            <div className="text-danger" style={{ color: '#ff4d4d', marginTop: '0.5rem' }}>
              {errors.fechaNacimiento}
            </div>
          )}
        </div>
        <button
          type="submit"
          className="btn btn-success"
          style={{
            backgroundColor: '#28a745',
            border: 'none',
            padding: '0.75rem 1.5rem',
            fontSize: '1rem',
            color: 'white',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background-color 0.3s ease',
          }}
          onMouseOver={(e) => (e.target.style.backgroundColor = '#218838')}
          onMouseOut={(e) => (e.target.style.backgroundColor = '#28a745')}
        >
          Crear
        </button>
      </form>
    </div>
  );
};

export default CrearUsuario;
