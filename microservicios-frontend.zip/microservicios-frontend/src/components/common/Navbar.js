import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav className="navbar navbar-expand-lg navbar-light" style={styles.navbar}>
    <div className="container" style={styles.container}>
      <Link className="navbar-brand" to="/" style={styles.brand}>
        Microservicios
      </Link>
      <button
        className="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
        style={styles.toggler}
      >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/usuarios" style={styles.link}>
              Usuarios
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/cursos" style={styles.link}>
              Cursos
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/matricular" style={styles.link}>
              Matricular Usuario
            </Link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
);

const styles = {
  navbar: {
    backgroundColor: '#343a40', // Dark background color for the navbar
    borderBottom: '2px solid #28a745', // Green border at the bottom
  },
  container: {
    paddingLeft: '2rem',
    paddingRight: '2rem',
  },
  brand: {
    color: '#28a745', // Green color for the brand
    fontWeight: 'bold',
    fontSize: '1.5rem',
    textTransform: 'uppercase',
    letterSpacing: '1px',
    transition: 'color 0.3s ease',
  },
  link: {
    color: '#f8f9fa', // Light color for links
    fontSize: '1.1rem',
    fontWeight: '500',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    transition: 'color 0.3s ease',
  },
  toggler: {
    border: 'none',
  },
};

export default Navbar;
