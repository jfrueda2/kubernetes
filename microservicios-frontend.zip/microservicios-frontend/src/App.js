import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/common/Navbar';
import ListarUsuarios from './components/Usuarios/ListarUsuarios';
import CrearUsuario from './components/Usuarios/CrearUsuario';
import EditarUsuario from './components/Usuarios/EditarUsuario';
import ListarCursos from './components/Cursos/ListarCursos';
import CrearCurso from './components/Cursos/CrearCurso';
import MatricularUsuario from './components/Cursos/MatricularUsuario';
import UsuariosMatriculados from './components/Cursos/UsuariosMatriculados';
import EditarCurso from './components/Cursos/EditarCurso';

const App = () => (
  <Router>
    <Navbar />
    <div className="container">
      <Routes>
        <Route path="/" element={<div style={styles.centered}>
          <div style={styles.greenText}>UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE</div>
          <br></br><br></br>
          <div>ESTUDIANTE: JUAN FRANCISCO RUEDA MESIAS</div>
          <br></br><br></br>
          <div>APLICACIONES DISTRIBUIDAS</div>
        </div>} />
        <Route path="/usuarios" element={<ListarUsuarios />} />
        <Route path="/usuarios/crear" element={<CrearUsuario />} />
        <Route path="/usuarios/editar/:id" element={<EditarUsuario />} />
        <Route path="/cursos" element={<ListarCursos />} />
        <Route path="/cursos/crear" element={<CrearCurso />} />
        <Route path="/cursos/editar/:id" element={<EditarCurso />} />
        <Route path="/matricular" element={<MatricularUsuario />} />
        <Route path="/cursos/:id/usuarios" element={<UsuariosMatriculados />} />
      </Routes>
    </div>
  </Router>
);

const styles = {
  centered: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    fontSize: '1.5rem',
    textAlign: 'center',
  },
  greenText: {
    color: '#008000', // Color verde
    fontSize: '2rem',
    fontWeight: 'bold',
  },
};

export default App;
